from os import getenv, environ

token = '1920102246:AAGPJx1uGMha44JXGktlqv1DtUny6ZzBSTc'

class Var(object):
	root_key = 'D3eJ8zsOKmPuSFd4LldgXv4q95d0XLHEeBgSd6T8piQ='
	API_ID = 12540404
	API_HASH = "1ae6ead152303b7b8c716c7f46333d6f"
	bot_id = int(token.split(':')[0])
	BOT_TOKEN = token
	SLEEP_THRESHOLD = int(getenv('SLEEP_THRESHOLD', '60'))
	WORKERS = int(getenv('WORKERS', '12'))
	BIN_CHANNEL = -1001795381295
	PORT = int(getenv('PORT', 2020))
	BIND_ADRESS = str(getenv('WEB_SERVER_BIND_ADDRESS', '0.0.0.0'))
	OWNER_ID = 1068352349
	NO_PORT = bool(getenv('NO_PORT', False))
	log_channel = -1001795381295
	bot_username = "@zero_two_movie_bot"
	if 'DYNO' in environ:
		ON_HEROKU = True
		APP_NAME = 'zerotwomaiis'
	else:
		ON_HEROKU = False
	FQDN = str(getenv('FQDN', BIND_ADRESS)) if not ON_HEROKU else APP_NAME+'.herokuapp.com'
